<?php
class AdminMyFacturaController extends ModuleAdminController
{
	public function __construct()
    {
 
        parent::__construct();
        Tools::redirectAdmin(Context::getContext()->link->getAdminLink('AdminModules').'&configure=factura');
 
	}	
	
}